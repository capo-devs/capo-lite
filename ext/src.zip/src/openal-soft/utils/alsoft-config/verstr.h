#ifndef VERSTR_H
#define VERSTR_H

#include <QString>

QString GetVersionString();

#endif /* VERSTR_H */
