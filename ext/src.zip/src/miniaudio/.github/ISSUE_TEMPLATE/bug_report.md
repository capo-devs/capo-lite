---
name: Bug report
about: Submit a bug report.
title: ''
labels: ''
assignees: ''

---

**DELETE ALL OF THIS TEXT BEFORE SUBMITTING**

If you think you've found a bug, it will be helpful to compile with `#define MA_DEBUG_OUTPUT`. If you are having issues with playback, please run the simple_payback_sine example and report whether or not it's consistent with what's happening in your program.
