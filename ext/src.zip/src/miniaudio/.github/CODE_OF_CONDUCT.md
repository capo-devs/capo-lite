Code of Conduct
===============
I don't believe we need a document telling fully grown adults how to conduct themselves within an open source
community. All I ask is that you just don't be unpleasant and keep everything on topic.
